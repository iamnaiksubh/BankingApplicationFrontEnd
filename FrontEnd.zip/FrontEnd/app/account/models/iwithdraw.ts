export interface IWithdraw {
    accountId: string;
    amount: number;
}
