export interface IDeposit {
    accountId: String;
    amount: number;
}
