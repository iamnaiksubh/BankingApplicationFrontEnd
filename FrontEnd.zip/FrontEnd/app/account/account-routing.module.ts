import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreateAccountComponent } from './components/account-forms/create-account/create-account.component';
import { DepositMoneyComponent } from './components/account-forms/deposit-money/deposit-money.component';
import { WithdrawMoneyComponent } from './components/account-forms/withdraw-money/withdraw-money.component';
import { ApplyLoanComponent } from './components/account-forms/apply-loan/apply-loan.component';

const routes: Routes = [
  {path: 'create-account', component: CreateAccountComponent},
  {path: 'deposit-money', component: DepositMoneyComponent},
  {path: 'withdraw-money', component: WithdrawMoneyComponent},
  {path: 'apply-loan', component: ApplyLoanComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AccountRoutingModule { }
