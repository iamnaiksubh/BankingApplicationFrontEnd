import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ILoan } from 'src/app/account/models/iloan';
import { LoanService } from 'src/app/account/services/loan.service';

@Component({
  selector: 'app-apply-loan',
  templateUrl: './apply-loan.component.html',
  styleUrls: ['./apply-loan.component.css']
})
export class ApplyLoanComponent {

  loan: ILoan = {
    loanType: '',
  loanAmount: 0,
  loanStatus: '',
  appliedDate: '',
  accountId: ''
  }
  constructor(private loanService: LoanService, private router: Router) { }

  onLoanApplication(){
    this.loan.accountId = JSON.parse(localStorage.getItem('accountDetails') || "").accountId;

    this.loanService.createLoan(this.loan).subscribe((res) => {

      localStorage.setItem("loanDetails", JSON.stringify(res));

      this.router.navigate(['/dashboard']);

    },

    (err) => {

      console.log(err);

    })
  }

}
