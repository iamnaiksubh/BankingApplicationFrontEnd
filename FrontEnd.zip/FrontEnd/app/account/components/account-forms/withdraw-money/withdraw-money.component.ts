import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IWithdraw } from 'src/app/account/models/iwithdraw';
import { AccountService } from 'src/app/account/services/account.service';

@Component({
  selector: 'app-withdraw-money',
  templateUrl: './withdraw-money.component.html',
  styleUrls: ['./withdraw-money.component.css']
})
export class WithdrawMoneyComponent {

  withdraw: IWithdraw = {
    accountId: '',
    amount: 0
  }
  constructor(private accountService: AccountService, private router: Router) { }

  onWithdraw(){
    this.withdraw.accountId = JSON.parse(localStorage.getItem('accountDetails') || '')[0]['accountId'];
    
    this.accountService.withdrawMoney(this.withdraw).subscribe(
      res => {
          console.log(res);
          this.router.navigate(['/dashboard']);
      },
      err => {
          console.log(err);
      }
    )
  }

}
