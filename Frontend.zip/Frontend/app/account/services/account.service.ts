import { Injectable } from '@angular/core';
import { IAccount } from '../models/iaccount';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { IDeposit } from '../models/ideposit';
import { IWithdraw } from '../models/iwithdraw';

const headerData = {
  headers: { 'Content-Type': 'application/json' },
};

@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private httpClient: HttpClient) {}
  endPoint: string = '/api/account';

  getAccountByUserId(userId: number): Observable<any> {
    return this.httpClient.get(this.endPoint + '/user/' + userId);
  }

  createAccount(account: IAccount): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/create',
      account,
      headerData
    );
  }

  depositMoney(deposit: IDeposit): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/deposit',
      deposit,
      headerData
    );
  }

  withdrawMoney(withdraw: IWithdraw): Observable<any> {
    return this.httpClient.post(
      this.endPoint + '/withdraw',
      withdraw,
      headerData
    );
  }
}
