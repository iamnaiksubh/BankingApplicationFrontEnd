import { Component, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';
import { IAccount } from 'src/app/account/models/iaccount';
import { AccountService } from 'src/app/account/services/account.service';

@Component({
  selector: 'app-create-account',
  templateUrl: './create-account.component.html',
  styleUrls: ['./create-account.component.css']
})
export class CreateAccountComponent {

  account: IAccount = {
    userId: '',
    accountType: '',
    accountStatus: '',
    pancardNumber: '',
    aadharcardNumber: '',
    balance: 0,
    mobileNumber: ''
  }

  constructor(private accountService: AccountService, private router: Router) { }

  onCreateAccount(){
    this.account.userId = JSON.parse(
      localStorage.getItem('userDetails') || ''
    ).id;

    console.log(this.account);
    this.accountService.createAccount(this.account).subscribe(
      (res) => {
        console.log(res);
        localStorage.setItem("accountDetails", JSON.stringify(res));
        this.router.navigate(['/dashboard']);
      },
      (err) => {
        console.log(err);
      }
    );
  }

}
