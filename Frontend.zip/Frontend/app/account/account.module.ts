import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AccountRoutingModule } from './account-routing.module';
import { CreateAccountComponent } from './components/account-forms/create-account/create-account.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AccountService } from './services/account.service';
import { WithdrawMoneyComponent } from './components/account-forms/withdraw-money/withdraw-money.component';
import { DepositMoneyComponent } from './components/account-forms/deposit-money/deposit-money.component';
import { ApplyLoanComponent } from './components/account-forms/apply-loan/apply-loan.component';
import { httpInterceptors } from '../shared/interceptors';
import { LoanService } from './services/loan.service';


@NgModule({
  declarations: [
    CreateAccountComponent,
    WithdrawMoneyComponent,
    DepositMoneyComponent,
    ApplyLoanComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    AccountRoutingModule
  ],
  providers: [AccountService, LoanService, httpInterceptors]
})
export class AccountModule { }
