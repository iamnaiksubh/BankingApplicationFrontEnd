export interface IAccount {
    userId: String,
    accountType: String,
    accountStatus: String,
    pancardNumber: String,
    aadharcardNumber: String,
    balance: number,
    mobileNumber: String
}
