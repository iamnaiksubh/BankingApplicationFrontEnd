export interface ILoan {
  loanType: string;
  loanAmount: number;
  loanStatus: string;
  appliedDate: string;
  accountId: string;
}
